"use strict";

const AWS = require("aws-sdk");
const awsOptions = {
  httpOptions: {
    timeout: 300000
  }
};
const s3 = new AWS.S3(awsOptions);
const archiver = require("archiver");
const stream = require("stream");

const streamTo = (bucket, key) => {
  var passthrough = new stream.PassThrough();
  s3.upload(
    {
      Bucket: bucket,
      Key: key,
      Body: passthrough,
      ContentType: "application/zip"
    },
    (err, data) => {
      if (err) throw err;
    }
  );
  return passthrough;
};

// Kudos to this person on GitHub for this getStream solution
// https://github.com/aws/aws-sdk-js/issues/2087#issuecomment-474722151
const getStream = (index, bucket, key) => {

  console.info('streaming file ' + index + ': ' + bucket + " from " + key)
      
  let streamCreated = false;
  const passThroughStream = new stream.PassThrough();

  passThroughStream.on("newListener", event => {
    if (!streamCreated && event == "data") {
      const s3Stream = s3
        .getObject({ Bucket: bucket, Key: key })
        .createReadStream();
      s3Stream
        .on("error", err => passThroughStream.emit("error", err))
        .pipe(passThroughStream);

      streamCreated = true;
    }
  });

  return passThroughStream;
};

const _outputBucket = 'sst-s3-testagency-sao-prdizdevops-terraform'
const _outputFile = 'test/deployment.zip'
//const _files2 = 
//	[
//		{"bucket":'sst-s3-testagency-saocdb-devizgut-filedrop',	"key":'aws-cloudwatch-metrics-ec2/processed/01.i-00053643cb944bf3d.CPUUtilization.json.gz'}
//	];
const _buckets = 
	[
//	  { Bucket: "sst-s3-testagency-saocdb-devizgut-filedrop", Prefix: "theprefix/" }
	  { Bucket: "sst-s3-testagency-saocdb-devizgut-filedrop" }
	];
	
exports.handler = async (event, context, callback) => {
  var _files = [];
  
  for (var bucket of _buckets) {
    console.info('checking ' + bucket.Bucket)
    
    var params = {
      Bucket: bucket.Bucket,
      Prefix: bucket.Prefix,
      MaxKeys: 1000
    }

    var d;
    do {
      try {
        d = await s3.listObjectsV2(params).promise();
      } catch(e) {
        throw e // an error occurred
      }
      d.Contents.shift();
      var content = [];
      for (var currentValue of d.Contents) {
        console.info('found ' + currentValue.Key)
        _files.push({"bucket": params.Bucket, "key": currentValue.Key});
      }
      params.ContinuationToken = d.nextContinuationToken;
    } while(d.IsTruncated)
  }
  console.info('found total files ' + _files.length)

  await new Promise(async (resolve, reject) => {
    console.info('writing to: ' + _outputBucket + " from " + _outputFile)
    var zipStream = streamTo(_outputBucket, _outputFile);
    zipStream.on("close", resolve);
    zipStream.on("end", resolve);
    zipStream.on("error", reject);

    var archive = archiver("zip");
    archive.on("error", err => {
      throw new Error(err);
    });
    archive.pipe(zipStream);

    var i = 1;
    for (const file of _files) {
      archive.append(getStream(i, file["bucket"], file["key"]), {
        name: file["key"]
      });
      ++i;
    }
    archive.finalize();
  }).catch(err => {
    throw new Error(err);
  });

  callback(null, {
    statusCode: 200,
    body: { final_destination: _outputFile }
  });
};